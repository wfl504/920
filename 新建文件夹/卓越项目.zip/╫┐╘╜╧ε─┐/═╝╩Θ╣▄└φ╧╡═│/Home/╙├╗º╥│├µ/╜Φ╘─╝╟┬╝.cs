﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.用户页面
{
    public partial class 借阅记录 : Form
    {
        public 借阅记录()
        {
            InitializeComponent();
        }

        private void LoadB()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = $"select * from zujie where [Uid] = '{登录.id}'";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                       reader[2].ToString(), reader[3].ToString(),
                                       reader[4].ToString(), reader[5].ToString(),reader[6].ToString(), reader[7].ToString());
            }
            reader.Close();
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;


        }
        private void 归还图书_Load(object sender, EventArgs e)
        {
           LoadB();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.Cells[1].Value == null)
            //{
            //    return;
            //}
            //string name = dataGridView1.CurrentRow.Cells[4].Value.ToString();//当前选中的书名
            //label3.Text = name;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ////拿到关键字
            //string key = textBox2.Text;
            //Dao dao = new Dao();
            //dao.connect();
            ////以关键字进行模糊查询
            //string sql = string.Format("select * from zujie where Uid like '%{0}%' or Uname like '%{0}%'or Bid like '%{0}%'or Bname like '%{0}%' or Status = '%{0}%'", key);
            ////MessageBox.Show(sql);
            //SqlDataReader reader = dao.reader(sql);
            ////清空表格
            //dataGridView1.Rows.Clear();
            ////显示表格
            //while (reader.Read())
            //{
            //    dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
            //                            reader[2].ToString(), reader[3].ToString(),
            //                            reader[4].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString());
            //}
            ////设置字体颜色为黑色
            //dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ////检测当前数据是否为空

            //if (label3.Text == "NULL")
            //{
            //    MessageBox.Show("未选中数据","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            //    return;
            //}

            //string BookID = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            //DateTime requestDateStr = DateTime.Now;

            //int key = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());

            //Dao dao = new Dao();
            //dao.connect();
            //string query = $"update zujie set Status = '待管理员批准' where [key] = {key}";
            //if (dao.Execute(query)>0)
            //{
            //    MessageBox.Show("申请成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    LoadB();
            //}
            // string sqlDelete = $"delete zujie where [key] = '{key}'";
            // string sqlUpdate = $"update TuShuXinxi set KuCun = KuCun +{int.Parse(dataGridView1.CurrentRow.Cells[6].Value.ToString())}" +
            //     $" where Bid = {int.Parse(dataGridView1.CurrentRow.Cells[3].Value.ToString())}";
            // if (dao.Execute(sqlUpdate) + dao.Execute(sqlDelete) >=2)
            // {
            //     //归还成功
            //     MessageBox.Show("归还成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //     LoadB();
            // }
            // else
            // {
            //     //归还失败
            //     MessageBox.Show("归还失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            // }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
