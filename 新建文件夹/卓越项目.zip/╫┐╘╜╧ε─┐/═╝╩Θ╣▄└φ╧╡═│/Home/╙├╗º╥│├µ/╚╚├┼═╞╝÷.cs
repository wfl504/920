﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Home.用户页面
{
    public partial class 热门推荐 : Form
    {
        public 热门推荐()
        {
            InitializeComponent();
        }

        private void 热门推荐_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=.;Initial Catalog=BookDB;Integrated Security=True;Encrypt=False";
            string query = "select top 3 Bname,ZuJieShuLiang from TuShuXinxi ORDER BY ZuJieShuLiang DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // 绑定到 DataGridView
                //dataGridView1.DataSource = dataTable;

                // 绑定到 Chart
                if (chart1.Series.Count == 0)
                {
                    chart1.Series.Add("Series1");
                }
                chart1.Series["Series1"].ChartType = SeriesChartType.Pie;
                chart1.Series["Series1"].Points.Clear(); // 清除旧数据

      

                foreach (DataRow row in dataTable.Rows)
                {
                    string bookTitle = row["Bname"].ToString();
                    int borrowCount = Convert.ToInt32(row["ZuJieShuLiang"]);

                    chart1.Series["Series1"].Points.AddXY(bookTitle, borrowCount);
                }
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
