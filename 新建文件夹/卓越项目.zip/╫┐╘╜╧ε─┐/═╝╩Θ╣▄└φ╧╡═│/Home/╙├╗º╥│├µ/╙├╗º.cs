﻿using Home.用户页面;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class 用户 : Form
    {
        public 用户()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            
        }

      

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定退出", "退出登录", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                
                this.Close();

                
            }
            else
            {
                e.GetHashCode();
            }
        }

        借阅记录 jl = new 借阅记录();
       
        
        private void menuStrip6_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //if (!panel3.Controls.Contains(cx))
            //{
            //    //如果不包括
            //    cx.TopLevel = false;
            //    cx.FormBorderStyle = FormBorderStyle.None;
            //    panel3.Controls.Add(cx);
            //    cx.Show();
            //    cx.BringToFront();
            //}
            //else
            //{
            //    //如果包括，就显示到最前端
            //    cx.BringToFront();
            //}
            //SetCon(cx);
        }

        private void menuStrip5_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 注销用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定注销当前账号？", "账户注销", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                //账户注销
                int id = 登录.id;
                Dao dao = new Dao();
                dao.connect();//连接数据库
                string sql = string.Format("delete Table_User where Uxh={0}", id);
                if (dao.Execute(sql) > 0)
                {
                    //注销成功
                    MessageBox.Show("注销账号成功", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    //返回登录窗口
                    Close();

                }
                else
                {
                    //注销失败
                    MessageBox.Show("注销账号失败", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                e.GetHashCode();
            }
        }

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            用户修改密码 form = new 用户修改密码();
            form.ShowDialog();
        }

        private void menuStrip7_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (!panel3.Controls.Contains(jl))
            {
                //如果不包括
                jl.TopLevel = false;
                jl.FormBorderStyle = FormBorderStyle.None;
                panel3.Controls.Add(jl);
                jl.Show();
                jl.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                jl.BringToFront();
            }
            SetCon(jl);
        }

        private void menuStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }
        void SetCon(Form f)
        {
            float newX = this.panel2.Width / Convert.ToSingle(f.Width);
            float newY = this.panel2.Height / Convert.ToSingle(f.Height);
            SetC(newX, newY, this.panel2);
        }
        void SetC(float x, float y, Control cons)
        {
            foreach (Control con in cons.Controls)
            {
                con.Width = Convert.ToInt32(con.Width * x);
                con.Height = Convert.ToInt32(con.Height * y);
                con.Left = Convert.ToInt32(con.Left * x);
                con.Top = Convert.ToInt32(con.Top * y);


                if (con.Controls.Count > 1)
                {
                    SetC(x, y, con);
                }
            }
        }

        private void menuStrip5_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //if (!panel3.Controls.Contains(jl))
            //{
            //    //如果不包括
            //    jl.TopLevel = false;
            //    jl.FormBorderStyle = FormBorderStyle.None;
            //    panel3.Controls.Add(jl);
            //    jl.Show();
            //    jl.BringToFront();
            //}
            //else
            //{
            //    //如果包括，就显示到最前端
            //    jl.BringToFront();
            //}
            //SetCon(jl);
        }
        图书评论 pl = new 图书评论();
        private void menuStrip4_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (!panel3.Controls.Contains(pl))
            {
                //如果不包括
                pl.TopLevel = false;
                pl.FormBorderStyle = FormBorderStyle.None;
                panel3.Controls.Add(pl);
                pl.Show();
                pl.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                pl.BringToFront();
            }
            SetCon(pl);
        }
        热门推荐 rm = new 热门推荐();
        private void menuStrip8_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (!panel3.Controls.Contains(rm))
            {
                //如果不包括
                rm.TopLevel = false;
                rm.FormBorderStyle = FormBorderStyle.None;
                panel3.Controls.Add(rm);
                rm.Show();
                rm.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                rm.BringToFront();
            }
            SetCon(rm);
        }

        private void menuStrip2_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {

        }
        借阅记录 jy = new 借阅记录();
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (!panel3.Controls.Contains(jy))
            {
                //如果不包括
                jy.TopLevel = false;
                jy.FormBorderStyle = FormBorderStyle.None;
                panel3.Controls.Add(jy);
                jy.Show();
                jy.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                jy.BringToFront();
            }
            SetCon(jy);
        }

        private void 图书评论ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
