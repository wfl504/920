﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.用户页面
{
    public partial class 图书评论 : Form
    {
        public 图书评论()
        {
            InitializeComponent();
        }
        private void LoadD()
        {
            try
            {
                dataGridView1.Rows.Clear();
                Dao dao = new Dao();
                dao.connect();
                string sql = $"select * from Table_PingLun";
                SqlDataReader reader = dao.reader(sql);

                Console.WriteLine("Loading Data...");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader[0].ToString()); // 打印第一列的值
                        dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                                reader[2].ToString(), reader[3].ToString(),
                                                reader[4].ToString(), reader[5].ToString(),
                                                reader[6].ToString(), reader[7].ToString());
                    }
                }
                else
                {
                    Console.WriteLine("LoadD: No rows found.");
                }

                reader.Close();
                //设置字体颜色为黑色
                dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in LoadD: " + ex.Message);
            }
        }

        private void LoadMyBook()
        {
            try
            {
                comboBox1.Items.Clear(); // 确保清空 comboBox1
                Dao dao = new Dao();
                dao.connect();
                string sql = $"select Bid from zujie where Uid={登录.id}";
                SqlDataReader reader = dao.reader(sql);

                Console.WriteLine("Loading My Books...");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader[0].ToString()); // 打印书籍ID
                        comboBox1.Items.Add(reader[0].ToString());
                    }
                }
                else
                {
                    Console.WriteLine("LoadMyBook: No rows found.");
                }

                reader.Close();
                //设置字体颜色为黑色
                dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in LoadMyBook: " + ex.Message);
            }
        }

        private void 图书评论_Load(object sender, EventArgs e)
        {
            //用户没有删除功能    管理员没有评论
            if (登录.id.ToString().Length == 4)
            {
                button2.Visible = false;
            }
            else
            {
                btnDelete.Visible = false;
            }

            //把评论区显示到网格
            LoadD(); // 加载评论

            //只能评论自己借过的书
            LoadMyBook(); // 加载借阅的书籍
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //检测控件内容
            if (label3.Text == "NULL" || comboBox1.Text =="" || textBox1.Text =="" || comboBox2.Text == "" )
            {
                MessageBox.Show("有空项！","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            //添加评论
            string Bid =comboBox1.Text;
            string Bname = label3.Text;
            int id = 登录.id;
            string name = 登录.name;
            string words = textBox1.Text;
            DateTime date = DateTime.Now;
            string score = comboBox2.Text;
            int key = 0;

            Dao dao = new Dao();
            dao.connect();
            string sql = $"select [key] from Table_PingLun where [key] = {key}";//到评论表里看有没有key 的数据
            SqlDataReader reader = dao.reader(sql);
            while (true)
            {
                key++;
                sql = $"select [key] from Table_PingLun where [key] = {key}";
                reader = dao.reader(sql);
                //reader.Close();

                if (!reader.HasRows)
                {
                    break;
                }
            }

            string sqlInsert = $"insert into Table_PingLun values('{key}','{Bid}','{Bname}','{id}','{name}','{words}','{date}','{score}')";
            if (dao.Execute(sqlInsert)>0)
            {
                //发表成功
                MessageBox.Show("发表成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                //发表失败
                MessageBox.Show("发表失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            LoadD();
            reader.Close ();
            
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            //获取当前选中的图书编号
            string id = comboBox1.Text;

            //通过编号到TuShuXinxi获取书名
            Dao dao = new Dao();
            dao.connect();
            string sql = $"select Bname from TuShuXinxi where Bid = {id}";
            SqlDataReader reader = dao.reader(sql);
            reader.Read();
            string name = reader[0].ToString();
            label3.Text = name;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //判断是否选择图书
            if (dataGridView1.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("选择无效书籍！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            //删除
            Dao dao = new Dao();
            dao.connect();
            string sql = $"delete Table_PingLun where [key] = {int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString())}";
            if (dao.Execute(sql) >0)
            {
                MessageBox.Show("删除成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("删除失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            LoadD();
 
        }
    }
}
