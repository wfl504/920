﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Home
{
    public class Dao
    {
        SqlConnection sc;
        public SqlConnection connect()
        {
            string str = "Data Source=.;Initial Catalog=BookDB;Integrated Security=True";
            // 使用连接字符串初始化一个新的 SqlConnection 对象 sc。
            sc = new SqlConnection(str);
            sc.Open();
            return sc;
        }

        // 创建并返回一个 SqlCommand 对象，用于执行 SQL 查询的方法。
        public SqlCommand command(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql,connect());
            return cmd;
        }


        // 执行非查询 SQL 命令并返回受影响的行数的方法。
        public int Execute(string sql)
        {  
             return command(sql).ExecuteNonQuery();
        }


        // 执行返回 SqlDataReader 用于读取结果的 SQL 查询的方法。
        public SqlDataReader reader(string sql)
        {
            return command(sql).ExecuteReader();
        }
        public void Dispose()
        {
            sc.Close();
        }

    }
}
