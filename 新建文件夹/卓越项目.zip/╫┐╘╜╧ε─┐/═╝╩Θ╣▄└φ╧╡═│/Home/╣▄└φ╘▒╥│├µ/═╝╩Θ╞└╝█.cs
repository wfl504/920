﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.管理员页面
{
    public partial class 图书评价 : Form
    {
        public 图书评价()
        {
            InitializeComponent();
        }
        private void LoadD()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = $"select * from Table_PingLun";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                       reader[2].ToString(), reader[3].ToString(),
                                       reader[4].ToString(), reader[5].ToString(),
                                       reader[6].ToString(), reader[7].ToString());
            }
            reader.Close();
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            
        }
        
        private void 图书评价_Load(object sender, EventArgs e)
        {
            //用户没有删除功能    管理员没有评论
            if (登录.id.ToString().Length == 4)
            {
                button2.Visible = false;
               
            }
            else
            {
                 btnDelete.Visible = false;
            }

            //把评论区显示到网格
            LoadD();
            //label3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            //textBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("选中无效数据！","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            Dao dao = new Dao();
            dao.connect();
            string sql = $"delete Table_PingLun where [key] = {dataGridView1.CurrentRow.Cells[0].Value.ToString()}";
            if (dao.Execute(sql)> 0)
            {
                //删除成功
                MessageBox.Show("删除成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                label3.Text = "NULL";
                textBox1.Text = "";
            }
            else
            {
                //删除失败
                MessageBox.Show("删除失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            LoadD();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.Cells[1].Value == null)
            {
                return;
            }
            label3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
