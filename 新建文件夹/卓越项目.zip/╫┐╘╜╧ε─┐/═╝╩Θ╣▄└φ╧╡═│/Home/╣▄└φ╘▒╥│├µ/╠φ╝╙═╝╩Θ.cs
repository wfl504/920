﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.管理员页面
{
    public partial class 添加图书 : Form
    {
        public 添加图书()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 将 DateTimePicker 控件的日期设置为当前日期
            dateTimePicker1.Value = DateTime.Now;
            // 设置 DateTimePicker 控件的格式为自定义
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            if (textBox1.Text=="" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" ||
                textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || dateTimePicker1.Text == "")
            {
                MessageBox.Show("有空项","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            //添加图书
            Dao dao = new Dao();
            dao.connect();
            string sql = string.Format("insert TuShuXinxi values({0},'{1}','{2}','{3}','{4}','{5}','{6}',{7},'{8}','0')",
                textBox1.Text, textBox2.Text, textBox3.Text,textBox4.Text,dateTimePicker1.Text, textBox5.Text, textBox6.Text, 
                textBox7.Text, textBox8.Text);
            //MessageBox.Show(sql);
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("添加成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK; // 设置结果
                this.Close(); // 关闭窗体
                //Close();
                //dao.Dispose();
            }
            else
            {
                MessageBox.Show("添加失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 添加图书_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
