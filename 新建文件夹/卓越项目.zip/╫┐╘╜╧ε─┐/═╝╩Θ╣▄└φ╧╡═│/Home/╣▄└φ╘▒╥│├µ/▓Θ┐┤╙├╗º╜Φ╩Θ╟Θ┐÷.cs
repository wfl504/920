﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class 查看用户借书情况 : Form
    {
        public 查看用户借书情况()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadB()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = $"select * from zujie";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                       reader[2].ToString(), reader[3].ToString(),
                                       reader[4].ToString(), reader[5].ToString(), reader[6].ToString());
            }
            reader.Close();
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;

            Dispose();
        }
        private void 查看用户借书情况_Load(object sender, EventArgs e)
        {
            //加载所有信息
            LoadB();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //拿到关键字
            string key = textBox2.Text;
            Dao dao = new Dao();
            dao.connect();
            //以关键字进行模糊查询
            string sql = string.Format("select * from zujie where Uid like '%{0}%' or Uname like '%{0}%' or Bname like '%{0}%'", key);
            //MessageBox.Show(sql);
            SqlDataReader reader = dao.reader(sql);
            //清空表格
            dataGridView1.Rows.Clear();
            //显示表格
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                       reader[2].ToString(), reader[3].ToString(),
                                       reader[4].ToString(), reader[5].ToString(), reader[6].ToString());
            }
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            Dispose();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
