﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.管理员页面
{
    public partial class 用户信息管理 : Form
    {
        public 用户信息管理()
        {
            InitializeComponent();
        }
        private void LoadB()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = $"select * from Table_User";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(),
                                       reader[2].ToString(), reader[3].ToString(),
                                       reader[4].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString());
            }
            reader.Close();
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }
        private void 用户信息管理_Load(object sender, EventArgs e)
        {
            //显示所以的用户信息
            LoadB();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadB();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
                string name = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                label3.Text = name;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //把用户表中  Used  ->0     1（真）  0（假）
            if (label3.Text == "NULL")
            {
                MessageBox.Show("未选中用户","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            Dao dao = new Dao();
            dao.connect();
            string sql = $"update Table_User set Used = 0 where Uxh = {dataGridView1.CurrentRow.Cells[3].Value.ToString()}";
            if (dao.Execute(sql) >0)
            {
                
                MessageBox.Show("用户被停止登录系统！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                LoadB();
            }

            else
            {
                MessageBox.Show("操作失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //把用户表中  Used  ->1     1（真）  0（假）
            if (label3.Text == "NULL")
            {
                MessageBox.Show("未选中用户", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Dao dao = new Dao();
            dao.connect();
            string sql = $"update Table_User set Used = 1 where Uxh = {dataGridView1.CurrentRow.Cells[3].Value.ToString()}";
            if (dao.Execute(sql) > 0)
            {
                          
                MessageBox.Show("用户允许登录系统！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                LoadB(); 
            }

            else
            {
                MessageBox.Show("操作失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //拿到关键字
            string key = textBox2.Text;
            Dao dao = new Dao();
            dao.connect();
            //以关键字进行模糊查询
            string sql = string.Format("select * from Table_User where Uname like '%{0}%' or Uxy like '%{0}%' or Ubj like '%{0}%' or Uxh like '%{0}%' or Sex like '%{0}%' or Used like '%{0}%' ", key);
            //MessageBox.Show(sql);
            SqlDataReader reader = dao.reader(sql);
            //清空表格
            dataGridView1.Rows.Clear();
            //显示表格
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(),
                                       reader[3].ToString(), reader[4].ToString(), reader[5].ToString(),
                                       reader[6].ToString());
            }
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            Dispose();
        }
    }
}
