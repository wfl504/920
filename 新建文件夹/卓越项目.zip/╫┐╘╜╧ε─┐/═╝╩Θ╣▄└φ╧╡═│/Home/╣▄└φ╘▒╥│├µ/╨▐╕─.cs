﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.管理员页面
{
    public partial class 修改 : Form
    {
        public 修改图书 xg;
        public 修改()
        {
            InitializeComponent();
        }
        修改图书 Get = new 修改图书();

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void 修改_Load(object sender, EventArgs e)
        {
            textBox1.Text = 修改图书.Bid.ToString();
            textBox2.Text = 修改图书.Bname;
            textBox3.Text = 修改图书.Author;
            textBox4.Text = 修改图书.Publisher;
            textBox5.Text = 修改图书.Type;
            textBox6.Text = 修改图书.Price.ToString();
            textBox7.Text = 修改图书.Num.ToString();
            dateTimePicker1.Text = 修改图书.PubDate;
            textBox8.Text = 修改图书.Introduce;

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //判断文本框中内容是否为空
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" ||
                textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || dateTimePicker1.Text == "" ||
                textBox8.Text == "")
            {
                MessageBox.Show("有空项","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            //修改信息
            Dao dao = new Dao();
            dao.connect();
            string sql = string.Format("update TuShuXinxi set Bid='{0}',Bname='{1}',ZuoZhe='{2}'," +
                "ChuBanShe='{3}',Date='{4}',Leixing='{5}',Price='{6}',KuCun='{7}',JianJie='{8}' where Bid = '{9}'", textBox1.Text, textBox2.Text, textBox3.Text,
                textBox4.Text,dateTimePicker1.Value, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text ,修改图书.Bid);
            //MessageBox.Show(sql);
            if (dao.Execute(sql)>0)
            {
                
                MessageBox.Show("修改成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
                xg.LoadBooks();
            }
            else
            {
                MessageBox.Show("修改失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            Dispose();
        }
    }
}
