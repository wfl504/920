﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Home.管理员页面
{
    public partial class 归还图书 : Form
    {

        public 归还图书()
        {
            InitializeComponent();
            
        }
        private int key;
        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            zjts.LoadBooks();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }
        public void 损坏(int Key)
        {
            key = Key;
        }
        private void 归还图书_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox2.BackColor = Color.White;
            textBox4.BackColor = Color.White;
            textBox5.BackColor = Color.White;
        }

        private string GetUserNameById(string userId)
        {
            string userName = string.Empty;

            Dao dao = new Dao();

            using (SqlConnection connection = dao.connect())
            {
                // 使用参数化查询
                string query = "SELECT Uname FROM Table_User WHERE Uxh = @UserId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // 添加参数
                    command.Parameters.AddWithValue("@UserId", userId);

                    // 执行查询
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // 确保列名匹配
                            userName = reader["Uname"].ToString(); // 使用正确的列名
                        }
                    }
                }
            }
            return userName;
            Dispose();
        }

        private void InitializeControls()
        {
            // 设置 TextBox2 为只读
            textBox2.ReadOnly = true;

            // 绑定事件
            textBox1.TextChanged += textBox1_TextChanged;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // 获取用户ID
            string userId = textBox1.Text;

            if (!string.IsNullOrEmpty(userId))
            {
                // 用 GetUserNameById 方法来查找用户姓名
                string userName = GetUserNameById(userId);
                textBox2.Text = userName; // 更新 textBox2 显示用户姓名
            }
            else
            {
                textBox2.Text = string.Empty; // 如果没有输入，清空 textBox2
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // 设置 TextBox4 和 TextBox5 为只读
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox4.BackColor = Color.White;
            textBox5.BackColor = Color.White;
            // 调用方法获取图书信息
            GetBookInfoById(textBox3.Text);
        }

        private void GetBookInfoById(string bookId)
        {

            Dao dao = new Dao();
            // 连接数据库
            using (SqlConnection connection = dao.connect())
            {
                // 使用参数化查询，避免 SQL 注入
                string sql = "SELECT Bname, Leixing FROM TuShuXinxi WHERE Bid = @BookId";
                SqlCommand command = dao.command(sql);
                
                command.Parameters.AddWithValue("@BookId", bookId); // 添加参数

               
                // 确保连接已打开
                //connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read()) // 检查是否有结果
                {
                    textBox4.Text = reader["Bname"].ToString(); // 填充书名
                    textBox5.Text = reader["Leixing"].ToString(); // 填充书籍类型
                }
                else
                {
                    // 如果没有，清空 textBox4  textBox5
                    textBox4.Text = string.Empty;
                    textBox5.Text = string.Empty;
                }
                textBox4.ReadOnly = true;
                textBox5.ReadOnly = true;
            }
        }
        public void gb()
        {
            textBox1.Text = "";
            textBox3.Text = "";
        }
        

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("有空项", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string Bname = textBox4.Text;
            string uid = textBox1.Text;
            string name = textBox2.Text;
            string Number = textBox3.Text;
            float Price =0;
            string Type = textBox5.Text;
            Dao dao = new Dao();
            using (SqlConnection connection = dao.connect())
            {
                string sql = $"SELECT Price FROM TuShuXinxi WHERE Bid = {Number}"; // SQL 查询语句
                SqlCommand command = new SqlCommand(sql, connection);
                //command.Parameters.AddWithValue("@BookId", Number); // 使用参数化查询，避免 SQL 注入

                //connection.Open();
                object result = command.ExecuteScalar(); // 执行查询，获取单一值
                if (result != null && float.TryParse(result.ToString(), out Price))
                {
                    // 成功获取价格
                }
                else
                {
                    MessageBox.Show("未找到对应的价格记录");
                    return; // 如果未找到价格，可以选择返回，或抛出异常
                }
            }

            损坏 sh = new 损坏(Bname, Type, Price, Number, name, uid);
            sh.ghf = this;
            sh.zjts = this;
            sh.ShowDialog();
        }
        public 借阅管理 zjts;
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text =="" || textBox3.Text =="")
            {
                MessageBox.Show("有空项", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string BookID = textBox3.Text;
            string Uid = textBox1.Text;
            string Bname = textBox4.Text;
            Dao dao = new Dao();
            dao.connect();
            string query = $"update zujie set Status = '已还书' where Uid = {Uid} and Bid = {BookID}";
            //MessageBox.Show(query);
            int num = 1;
            if (dao.Execute(query) > 0)
            {
                string updateSql = $"UPDATE TuShuXinxi SET KuCun = KuCun + {num} WHERE Bid = {BookID} and Bname = '{Bname}'";
                dao.Execute(updateSql);
                MessageBox.Show("还书成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
                zjts.LoadBooks();
            }
            else
            {
                MessageBox.Show("用户不存在！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                gb();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 阻止回车键的默认行为
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 阻止回车键的默认行为
            }
        }
    }
}
