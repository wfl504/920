﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net.Mail;
using System.Net;
using System.Diagnostics;
using System.Security.Cryptography;


namespace Home.管理员页面
{
    public partial class 损坏 : Form
    {
        public 归还图书 ghf;
        public 归还图书 zjts;
        private 归还图书 _归还;
        public 损坏(归还图书 归还)
        {
            InitializeComponent();
            _归还 = 归还;
        }
         



        private string _bookName;//书名
        private string _bookType;//类型
        private float _originalPrice;//原价
        private string _bookNumber;//编号
        private string _Uname;
        private string _UID;
        private int key;

        public 损坏(string Bname, string Type,float Price, string Number, string name,string uid )
        {
            InitializeComponent();
            _bookName = Bname;
            _bookType = Type;
            _originalPrice = Price;
            _bookNumber = Number;
            _Uname = name;
            _UID = uid;
            
        }
        private void 损坏_Load(object sender, EventArgs e)
        {
            label2.Text = _bookName;
            label4.Text = _bookNumber.ToString();
            label6.Text = _bookType;
            label10.Text = _Uname;
            label13.Text = _UID;
            label8.Text = _originalPrice.ToString();
            //float labelPrice;
            //bool isConversionSuccessful = float.TryParse(label8.Text, out labelPrice);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || textBox1.Text == "")
            {
                MessageBox.Show("有空项","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            Dao dao = new Dao();
            dao.connect();
            string Type = comboBox1.Text;//损害类型
            float Price = float.Parse(textBox1.Text);//赔偿金额
            string bookName = label2.Text;//书名
            string bookType = label6.Text; //类型
            float originalPrice = float.Parse(label8.Text) ;//原价
            string bookNumber = label4.Text;//编号
            string Uname = label10.Text;//用户名
            string UID = label13.Text;//用户ID
            string sql = $"insert into SunHuai values('{Uname}',{UID},'{bookName}',{bookNumber},'{bookType}',{originalPrice},'{Type}',{Price})";
            //string Email = $"select [E-mail] from Table_User where Uname = '{Uname}' and Uxh = {UID}";
            //dao.reader(Email);
            //实例化一个发送邮件类
            // 创建邮件消息
            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("2715602713@qq.com"),
                Subject = "图书信息系统管理",
                Body = $"{Uname}您好！您借阅的书籍《{bookName}》有丢失，编号为{bookNumber}，图书类型为{bookType}，书籍原价为{originalPrice}，赔偿的金额为{Price}，请联系管理员缴费。",
                IsBodyHtml = false
            };

            // 确保邮箱地址为字符串并正确传递
            mailMessage.To.Add(new MailAddress("840473090@qq.com"));

            // 设置 SMTP 客户端
            SmtpClient client = new SmtpClient
            {
                Host = "smtp.qq.com",
                EnableSsl = true,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("2715602713@qq.com", "ucwlobepcpuyddaa") // 邮箱授权码
            };

            try
            {
                client.Send(mailMessage);
                string query = $"update zujie set Status = '已还书' where Uid = {UID} and Bid = {bookNumber}";
                dao.Execute(query);
                MessageBox.Show("邮件发送成功！","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                Close();
                ghf.gb();
                

                //ghf.LoadB();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"发送邮件时发生错误: {ex.Message}");
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
