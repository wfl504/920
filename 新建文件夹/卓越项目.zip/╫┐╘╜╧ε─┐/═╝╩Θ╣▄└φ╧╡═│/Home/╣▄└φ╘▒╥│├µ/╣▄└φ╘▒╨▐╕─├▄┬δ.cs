﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class 管理员修改密码 : Form
    {
        public 管理员修改密码()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text =="" || textBox2.Text == "" || textBox3.Text=="")
            {
                MessageBox.Show("有空项","消息提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("新密码和确认密码不匹配", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }
            Dao dao = new Dao();
            dao.connect();
            //查看数据库中的原密码
            string sql = string.Format("select Pwd from Table_root where rootID={0}",登录.id);
            SqlDataReader reader = dao.reader(sql);
            //通过读取器读取
            reader.Read();
            if (reader[0].ToString() != textBox1.Text)
            {
                MessageBox.Show("原密码不正确", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //修改密码
            try
            {
                sql = string.Format("update Table_root set Pwd={0} where rootID={1}", textBox2.Text, 登录.id);
                if (dao.Execute(sql) > 0)
                {
                    MessageBox.Show("修改成功！", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    reader.Close();//关闭阅读器
                    
                    Close();
                }
                else
                {
                    MessageBox.Show("修改失败！", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR！", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }
    }
}
