﻿using Home.管理员页面;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class 修改图书 : Form
    {
        
        public 修改图书()
        {
            InitializeComponent();
        }
        //修改图书功能
        public static string Bid; // 编号
        public static string Bname;//书名
        public static string Author;//作者
        public static string Publisher;//出版社
        public static string PubDate;// 出版时间
        public static string Type;  //类型
        public static int Num;    //库存
        public static float Price;//价格
        public static string Introduce;//简介

        private void button5_Click(object sender, EventArgs e)
        {
            //获取图书编号
            Dao dao = new Dao();
            dao.connect();
            string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();//当前选中的ID
            if (label3.Text == "NULL")
            {
                MessageBox.Show("未选中图书", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
           DialogResult red = MessageBox.Show("确定下架该书吗?","删除提示",MessageBoxButtons.OKCancel,MessageBoxIcon.Information);
            if (red == DialogResult.OK)
            {
                string sql = string.Format("delete TuShuXinxi where Bid = {0}", id);
                //MessageBox.Show(sql);
                if (dao.Execute(sql) > 0)
                {
                    label3.Text = "NULL";
                    //更新表

                    MessageBox.Show("下架成功", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadBooks();
                }
                else
                {
                    MessageBox.Show("下架失败", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        public void LoadBooks()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = "select * from TuShuXinxi";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(),
                                       reader[3].ToString(), reader[4].ToString(), reader[5].ToString(),
                                       reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), reader[9].ToString());
            }
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }
     
        private void 修改图书_Load(object sender, EventArgs e)
        {
            //在窗体加载时显示所有的数据
            LoadBooks();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.Cells[1].Value == null)
            {
                return;
            }
            string name = dataGridView1.CurrentRow.Cells[1].Value.ToString();//当前选中的书名
            label3.Text = name;






            //===========
            Bid = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            Bname = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            Author = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            Publisher = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            PubDate = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            Type = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            Num = int.Parse(dataGridView1.CurrentRow.Cells[7].Value.ToString());
            Price = float.Parse(dataGridView1.CurrentRow.Cells[6].Value.ToString());
            Introduce = dataGridView1.CurrentRow.Cells[8].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //清空表格
            dataGridView1.Rows.Clear();
            LoadBooks();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (label3.Text == "NULL")
            {
                MessageBox.Show("未选中图书！","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            //获取图书编号
            Dao dao = new Dao();
            dao.connect();
            string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();//当前选中的ID
            string sql = string.Format("select JianJie from TuShuXinxi where Bid = {0}",id);
            //MessageBox.Show(sql);
            SqlDataReader reader = dao.reader(sql);
            reader.Read();
            string introduce = reader[0].ToString();
            //通过对话框形式显示图书简介
            MessageBox.Show(introduce, $"{label3.Text}的简介", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //拿到关键字
            string key = textBox2.Text;
            Dao dao = new Dao();
            dao.connect();
            //以关键字进行模糊查询
            string sql = string.Format("select * from TuShuXinxi where Bname like '%{0}%' or ZuoZhe like '%{0}%' or ChuBanShe like '%{0}%' or Leixing like '%{0}%'",key);
            //MessageBox.Show(sql);
            SqlDataReader reader = dao.reader(sql);
            //清空表格
            dataGridView1.Rows.Clear();
            //显示表格
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(),
                                       reader[3].ToString(), reader[4].ToString(), reader[5].ToString(),
                                       reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), reader[9].ToString());
            }
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            修改 from = new 修改();
            from.xg = this;
            from.ShowDialog();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
