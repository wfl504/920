﻿using Home;
using Home.管理员页面;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class 管理员首页 : Form
    {
        
        public 管理员首页()
        {
            InitializeComponent();
        }
         借阅管理 jy = new 借阅管理();
        添加图书 tj = new 添加图书();
        修改图书 xg = new 修改图书();
        //用户反馈 fk = new 用户反馈();
        管理员修改密码 mm = new 管理员修改密码();
        查看用户借书情况 ck = new 查看用户借书情况();
        用户信息管理 user = new 用户信息管理();
        图书评价 pj = new 图书评价();
        
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定退出","退出登录",MessageBoxButtons.YesNo,MessageBoxIcon.Information)==DialogResult.Yes)
            {
                //Dispose();
                ////退出应用程序
                //Application.Exit();
                this.Close();

                //登录 from = new 登录();
                //from.ShowDialog();           
            }
            else
            {
                e.GetHashCode();              
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
        
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(ck))
            {
                //如果不包括
                ck.TopLevel = false;
                ck.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(ck);
                ck.Show();
                ck.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                ck.BringToFront();
            }
            SetCon(ck);
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(pj))
            {
                //如果不包括
                pj.TopLevel = false;
                pj.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(pj);
                pj.Show();
                pj.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                pj.BringToFront();
            }
            SetCon(pj);
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(tj))
            {
                //如果不包括
                tj.TopLevel = false;
                tj.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(tj);
                tj.Show();
                tj.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                tj.BringToFront();
            }
            SetCon(tj);
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(xg))
            {
                //如果不包括
                xg.TopLevel = false;
                xg.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(xg);
                xg.Show();
                xg.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                xg.BringToFront();
            }
            SetCon(xg);

        }

        private void toolStripMenuItem16_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定注销当前账号？", "账户注销", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                //账户注销
                long id = 登录.id;
                Dao dao = new Dao();
                dao.connect();//连接数据库
                string sql = string.Format("delete Table_root where rootID={0}",id);
                if (dao.Execute(sql)>0)
                {
                    //注销成功
                    MessageBox.Show("注销账号成功","消息提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    

                    //返回登录窗口
                    Close();

                }
                else
                {
                    //注销失败
                    MessageBox.Show("注销账号失败", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                e.GetHashCode();
            }
        }

        private void toolStripMenuItem15_Click_1(object sender, EventArgs e)
        {
            管理员修改密码 mm = new 管理员修改密码();
            if (!panel2.Controls.Contains(mm))
            {
                //如果不包括
                mm.TopLevel = false;
                mm.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(mm);
                mm.Show();
                mm.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                mm.BringToFront();
            }
            SetCon(mm);

        }

        查看用户借书情况 form1 = new 查看用户借书情况();
       
        private void 正常借书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(form1))
            {
                //如果不包括
                form1.TopLevel = false;
                form1.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(form1);
                form1.Show();
                form1.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                form1.BringToFront();
            }
            SetCon(form1);

        }

       
        
        private void 归还图书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }
        void SetCon(Form f)
        {
            float newX = this.panel2.Width / Convert.ToSingle(f.Width);
            float newY = this.panel2.Height / Convert.ToSingle(f.Height);
            SetC(newX, newY, this.panel2);
        }
        void SetC(float x,float y,Control cons)
        {
            foreach (Control con in cons.Controls)
            {
                con.Width = Convert.ToInt32(con.Width * x);
                con.Height = Convert.ToInt32(con.Height * y);
                con.Left = Convert.ToInt32(con.Left * x);
                con.Top = Convert.ToInt32(con. Top  * y);


                if (con.Controls.Count>1)
                {
                    SetC(x, y, con);
                }
            }
        }
        
        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            if (!panel2.Controls.Contains(pj))
            {
                //如果不包括
                pj.TopLevel = false;
                pj.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(pj);
                pj.Show();
                pj.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                pj.BringToFront();
            }
            SetCon(pj);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {

            if (!panel2.Controls.Contains(user))
            {
                //如果不包括
                user.TopLevel = false;
                user.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(user);
                user.Show();
                user.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                user.BringToFront();
            }
            SetCon(user);
        }

        private void 借书管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //    if (!panel2.Controls.Contains(gh))
            //    {
            //        如果不包括
            //        gh.TopLevel = false;
            //        gh.FormBorderStyle = FormBorderStyle.None;
            //        panel2.Controls.Add(gh);
            //        gh.Show();
            //        gh.BringToFront();
            //    }
            //    else
            //    {
            //        如果包括，就显示到最前端
            //        gh.BringToFront();
            //    }
            //    SetCon(gh);
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {

            if (!panel2.Controls.Contains(jy))
            {
                //如果不包括
                jy.TopLevel = false;
                jy.FormBorderStyle = FormBorderStyle.None;
                panel2.Controls.Add(jy);
                jy.Show();
                jy.BringToFront();
            }
            else
            {
                //如果包括，就显示到最前端
                jy.BringToFront();
            }
            SetCon(jy);
        }
    }
}
