﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home.管理员页面
{
    public partial class 借阅管理 : Form
    {
        public 借阅管理()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            租借图书 zj = new 租借图书();
            zj.zjts = this;
            zj.ShowDialog();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            
            归还图书 gh = new 归还图书();
            gh .zjts = this;
            gh.ShowDialog();
        }

        private void 借阅管理_Load(object sender, EventArgs e)
        {
            LoadBooks();
        }
        public void LoadBooks()
        {
            dataGridView1.Rows.Clear();
            Dao dao = new Dao();
            dao.connect();
            string sql = "select * from zujie";
            SqlDataReader reader = dao.reader(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(),
                                       reader[3].ToString(), reader[4].ToString(), reader[5].ToString(),
                                       reader[6].ToString(),reader[7].ToString());
            }
            //设置字体颜色为黑色
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            dataGridView1.Columns[5].Width = 180;
        }
    }
}
