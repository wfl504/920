﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Home.管理员页面
{
   
    public partial class 租借图书 : Form
    {
        public 借阅管理 zjts; 
        public 租借图书()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 检查文本框是否为空
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("有空项", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string Uid = textBox1.Text;
            string Uname = textBox2.Text;
            string name = textBox4.Text;
            string Bid = textBox3.Text;
            int num = 1;
            DateTime date = DateTime.Now;
            string formattedDate = date.ToString("yyyy-MM-dd HH:mm:ss");
            int key = 1;

            Dao dao = new Dao();
            dao.connect();

            // 查询已有的租借记录
            string checkSql = $"SELECT num FROM zujie WHERE Uid = '{Uid}' AND Uname = '{Uname}' AND Bid = {Bid} AND Bname = '{name}'";
            SqlDataReader reader = dao.reader(checkSql);

            if (reader.Read())
            {
                // 如果已存在相同的记录，增加 num
                num += reader.GetInt32(0); // 假设 num 在数据库中是 int 类型
                reader.Close();

                // 更新现有记录
                string sqlUpdate = $"UPDATE zujie SET num = {num} WHERE Uid = '{Uid}' AND Uname = '{Uname}' AND Bid = {Bid} AND Bname = '{name}'";
                dao.Execute(sqlUpdate);
                // 库存更新逻辑
                string updateStockSql = $"UPDATE TuShuXinxi SET KuCun = KuCun - {num}, ZuJieShuLiang = ZuJieShuLiang + {num} WHERE Bid = {Bid}";
                dao.Execute(updateStockSql);
                string query = $"update zujie set Status = '阅读中' where Uid = {Uid} and Bid = {Bid}";
                dao.Execute(query);

                // 租借成功
                MessageBox.Show("租借成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
                zjts.LoadBooks(); // 更新表格
            }
            else
            {
                reader.Close();

                // 查找新的 key 值
                string sqlKey = $"SELECT [key] FROM zujie WHERE [key] ='{key}'"; // 查看是否有相同的 key
                reader = dao.reader(sqlKey);
                reader.Read();

                while (true)
                {
                    key++;
                    sqlKey = $"SELECT [key] FROM zujie WHERE [key] ='{key}'";
                    reader = dao.reader(sqlKey);
                    reader.Read();

                    if (!reader.HasRows)
                    {
                        break;
                    }
                }
                reader.Close();

                // 判断库存是否充足
                string sqlFlag = $"SELECT Bid FROM TuShuXinxi WHERE 0 <= KuCun - {num} AND Bid = {Bid}";
                SqlDataReader reader1 = dao.reader(sqlFlag);
                if (!reader1.Read())
                {
                    MessageBox.Show("库存不足！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    reader1.Close();
                    return;
                }

                // 插入新记录
                string insertSql = $"INSERT INTO zujie VALUES ({key}, {Uid}, '{Uname}', {Bid}, '{name}', '{date}', {num}, '阅读中')";
                string sqlUpdateStock = $"UPDATE TuShuXinxi SET KuCun = KuCun - {num}, ZuJieShuLiang = ZuJieShuLiang + {num} WHERE Bid = {Bid}";

                if (dao.Execute(insertSql) + dao.Execute(sqlUpdateStock) >= 2)
                {
                    // 租借成功
                    MessageBox.Show("租借成功！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                    zjts.LoadBooks(); // 更新表格
                }
                else
                {
                    MessageBox.Show("租借失败！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        private void InitializeControls()
        {
            // 设置 TextBox2 为只读
            textBox2.ReadOnly = true;

            // 绑定事件
            textBox1.TextChanged += textBox1_TextChanged;

        }
        private string GetUserNameById(string userId)
        {
            string userName = string.Empty;

            Dao dao = new Dao();

            using (SqlConnection connection = dao.connect())
            {
                // 使用参数化查询
                string query = "SELECT Uname FROM Table_User WHERE Uxh = @UserId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // 添加参数
                    command.Parameters.AddWithValue("@UserId", userId);

                    // 执行查询
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // 确保列名匹配
                            userName = reader["Uname"].ToString(); // 使用正确的列名
                        }
                    }
                }
            }
            return userName;
            Dispose();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // 获取用户ID
            string userId = textBox1.Text;

            if (!string.IsNullOrEmpty(userId))
            {
                // 用 GetUserNameById 方法来查找用户姓名
                string userName = GetUserNameById(userId);
                textBox2.Text = userName; // 更新 textBox2 显示用户姓名
            }
            else
            {
                textBox2.Text = string.Empty; // 如果没有输入，清空 textBox2
            }
        }
        private void GetBookInfoById(string bookId)
        {

            Dao dao = new Dao();
            // 连接数据库
            using (SqlConnection connection = dao.connect())
            {
                // 使用参数化查询，避免 SQL 注入
                string sql = "SELECT Bname, Leixing FROM TuShuXinxi WHERE Bid = @BookId";
                SqlCommand command = dao.command(sql);

                command.Parameters.AddWithValue("@BookId", bookId); // 添加参数


                // 确保连接已打开
                //connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read()) // 检查是否有结果
                {
                    textBox4.Text = reader["Bname"].ToString(); // 填充书名
                    textBox5.Text = reader["Leixing"].ToString(); // 填充书籍类型
                }
                else
                {
                    // 如果没有，清空 textBox4  textBox5
                    textBox4.Text = string.Empty;
                    textBox5.Text = string.Empty;
                }
                textBox4.ReadOnly = true;
                textBox5.ReadOnly = true;
            }
        }

        private void 租借图书_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox2.BackColor = Color.White;
            textBox4.BackColor = Color.White;
            textBox5.BackColor = Color.White;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // 设置 TextBox4 和 TextBox5 为只读
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox4.BackColor = Color.White;
            textBox5.BackColor = Color.White;
            // 调用方法获取图书信息
            GetBookInfoById(textBox3.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 阻止回车键的默认行为
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 阻止回车键的默认行为
            }
        }
    }
}
