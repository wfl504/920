﻿using Home.登录和注册页面;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace Home
{
    public partial class 登录 : Form
    {
        public 登录()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReg_Click(object sendersender, EventArgs e)
        {
            注册 form = new 注册();
            form.ShowDialog();
        }

        //用户的账号密码
        public static int id;
        public static string name;
       
        //管理员登录的方法
        private void Rootlogon()
        {
            int id = int.Parse(txtUserName.Text);
            string pwd = Pass.Text;
            Dao dao = new Dao();
            dao.connect();
            string sql = string.Format("select * from Table_root where rootID = {0} and Pwd = '{1}'",id,pwd);
            SqlDataReader reader = dao.reader(sql);
            if(reader.Read()==true)
            {
                //表里有该用户
                登录.id = id;
                sql = string.Format("select Name from Table_root where rootID = {0}",id);
                reader = dao.reader(sql);
                reader.Read();
                登录.name = reader[0].ToString();

                //登录成功后清空账号密码
                txtUserName.Text = "";
                Pass.Text = ""; 
                reader.Close();
                
                //登录成功
                //MessageBox.Show("登录成功");
                管理员首页 from = new 管理员首页();
                from.ShowDialog();

            }
            else
            {
                MessageBox.Show("账号密码错误","温馨提示！");
            }
        }

        //用户登录
        private void UserLogon()
        {
            int id = int.Parse(txtUserName.Text);
            string pwd = Pass.Text;
            
            Dao dao = new Dao();
            dao.connect();
            string sql = string.Format("select * from Table_User where Uxh = {0} and Pwd = {1}", id, pwd);
            SqlDataReader reader = dao.reader(sql);
            if (reader.Read() == true)
            {
                //再做一个判断，看看是否有登录权限
                string sqlStatus = $"select Used from Table_User where  Uxh = {int.Parse(txtUserName.Text)}";
                reader = dao.reader(sqlStatus);
                reader.Read();
                if ((bool)reader[0] != true)
                {
                    //没有登录权限
                    MessageBox.Show("您的账号没有登录权限！\n\r请联系管理员QQ:2715602713","消息",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }


                //表里有该用户
                登录.id = id;
                sql = string.Format("select Uname from Table_User  where Uxh = {0}", id);
                reader = dao.reader(sql);
                reader.Read();
                登录.name = reader[0].ToString();

                //登录成功后清空账号密码
                txtUserName.Text = "";
                Pass.Text = "";
                reader.Close();

                //登录成功
                //MessageBox.Show("登录成功");
                用户 from = new 用户();
                from.ShowDialog();

            }
            else
            {
                MessageBox.Show("账号密码错误", "温馨提示！");
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // 判断是否勾选相关政策
            if (!checkBox1.Checked)
            {
                MessageBox.Show("请勾选我已知晓相关政策", "温馨提示！");
                return; // 中止登录流程
            }

            // 判断文本框是否有内容
            if (txtUserName.Text == "" || Pass.Text == "")
            {
                MessageBox.Show("账号或密码有空项", "温馨提示！");
                return;
            }

            // 登录对象
            if (rbtnroot.Checked == true)
            {
                // 管理员登录
                Rootlogon();
            }
            else
            {
                // 用户登录
                UserLogon();
            }
        }

        private void cmb下拉框_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void 注册_Click_1(object sender, EventArgs e)
        {
            注册 from = new 注册();
            from.ShowDialog();
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            忘记密码 from = new 忘记密码();
            from.ShowDialog();

        }

        private void Pass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
