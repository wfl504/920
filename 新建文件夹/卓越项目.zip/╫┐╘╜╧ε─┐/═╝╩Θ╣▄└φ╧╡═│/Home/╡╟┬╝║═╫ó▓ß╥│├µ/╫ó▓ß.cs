﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class 注册 : Form
    {
        public 注册()
        {
            InitializeComponent();
        }
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtUserName_Leave(object sender, EventArgs e)
        {
            //当控件不再是活动控件时  进行用户名检测
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            //在这里使用change事件来判断是否超长
            if (txtUserName.Text.Length>15)
            {
                MessageBox.Show("用户名最大长度为15个字符");
                txtUserName.Text = txtUserName.Text.Substring(0, 15);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string uname = txtUserName.Text.Trim();//用户名
            string xueyuan = txtXueYuan.Text.Trim();//学院
            string banji = txtBanJi.Text.Trim();//班级
            string xuehao = txtXueHao.Text.Trim();//学号
            string pass = txtPass.Text.Trim();//密码
            string copass = txtCoPass.Text.Trim();//确认密码
            string cmbsex = cmbSex.Text.Trim();//性别
            string mali = txtPhon.Text.Trim();//电话号码
            if (string.IsNullOrEmpty(uname) || string.IsNullOrEmpty(xueyuan) ||
                string.IsNullOrEmpty(banji) || string.IsNullOrEmpty(xuehao) ||
                string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(copass) || string.IsNullOrEmpty(cmbsex) || string.IsNullOrEmpty(mali))
            {
                MessageBox.Show("请填写所有红色部分的内容");
                return;
            }

            //判断两次密码输入是否一致
            if (pass != copass)
            {
                MessageBox.Show("两次密码不一致,请从新输入！");
                txtPass.Text = "";
                txtCoPass.Text = "";
                return;
            }

            //开始插入数据库
            Dao dao = new Dao();//连接数据库
            dao.connect();
            //string name = txtUserName.Text;//用户名
            //string xy = txtXueYuan.Text;//学院
            //string bj = txtBanJi.Text;//班级
            //string xh = txtXueHao.Text;//学号
            //string dh = txtPhon.Text;//电话号码
            //string xb = cmbsex;//性别
            //string mm = txtPass.Text;//密码
            //进行添加
            //string sql = $"insert into Table_User values('{name}','{xy}','{bj}','{xh}','{dh}','{xb}','{mm}','1')";
            string sql = $"insert Table_User values('{uname}','{xueyuan}','{banji}','{xuehao}','{mali}','{cmbsex}','{pass}','1')";
            
            if (dao.Execute(sql)>0)
            {
                //注册成功
                DialogResult result = MessageBox.Show($"恭喜{uname}注册成功,是否要返回登录页面", "温馨提示！", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                

                if (result == DialogResult.OK)
                {
                    this.Close();
                }
                if (result == DialogResult.Cancel)
                {
                    //点击取消  清空输入框内容
                    txtUserName.Text = "";//用户名
                    txtPhon.Text = "";//学院
                    txtBanJi.Text = "";//班级
                    txtPhon.Text = "";//学号
                    cmbSex.Text = "";//性别
                    txtPass.Text = "";//密码
                }
            }
            else
            {
                //注册失败
                MessageBox.Show("注册失败");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbSex_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void 注册_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                // 可以在这里自定义行为
                e.SuppressKeyPress = true; // 如果需要阻止默认行为
            }
        }
    }
}
