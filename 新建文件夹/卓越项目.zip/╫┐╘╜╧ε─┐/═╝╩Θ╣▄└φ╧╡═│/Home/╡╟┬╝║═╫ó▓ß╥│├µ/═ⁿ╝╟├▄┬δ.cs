﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Home.登录和注册页面
{
    public partial class 忘记密码 : Form
    {
        public 忘记密码()
        {
            InitializeComponent();
        }
        string ecode;
        private void button2_Click(object sender, EventArgs e)
        {
            
            Dao dao = new Dao();
            dao.connect();
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("请注意带有" + label4.Text + "号的行不能有空", "失败提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //textBox1.Text = Uxh
            string sql = $"select * from Table_User where Uxh = {int.Parse(textBox1.Text)} and Uname = '{textBox2.Text}' and [E-mail] = '{textBox3.Text}'";
            SqlDataReader reader = dao.reader(sql);
            if (reader.HasRows)
            {
                if (textBox4.Text != ecode)
                {
                    MessageBox.Show("您的验证码不正确，请核实！", "失败提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                if (textBox4.Text == ecode)
                {
                    if (textBox6.Text != textBox5.Text)
                    {
                        MessageBox.Show("您的密码不同，请重新输入！", "失败提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    if (textBox6.Text == textBox5.Text)
                    {
                        string updata = $"update Table_User set Pwd = {int.Parse(textBox5.Text)} where Uxh = {int.Parse(textBox1.Text)} and Uname = '{textBox2.Text}'";
                        if (dao.Execute(updata) > 0)
                        {
                            MessageBox.Show("修改成功！！！");
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("修改失败,请查看数据是否正确！");
                        }
                    }
                }
            }         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dao dao = new Dao();
            dao.connect();

            //实例化一个发送邮件类
            MailMessage mailMessage = new MailMessage();
            //发件人邮箱地址，方法重载不同，可以根据需求自行选择
            mailMessage.From = new MailAddress("2715602713@qq.com");
            //收件人邮箱地址
            string sql = $"select * from Table_User where Uxh = {int.Parse(textBox1.Text)} and Uname = '{textBox2.Text}' and [E-mail] = '{textBox3.Text}'";
            SqlDataReader reader = dao.reader(sql);
            if (reader.HasRows)
            {
                mailMessage.To.Add(new MailAddress(textBox3.Text));//不能为空，或更改为邮箱                                  
                                                                   //邮件标题
                mailMessage.Subject = "图书信息系统管理";
                //随机数
                Random rd = new Random();
                string rs = Convert.ToString(rd.Next(100000, 999999));//6位数
                ecode = rs;
                //邮件内容
                mailMessage.Body = "----忘记密码修改----\n"+"你的验证码是" + rs +"\n----提供给他人会导致您的数据丢失！！！";
                //实例化一个SmtpClient类
                SmtpClient client = new SmtpClient();
                //在这里我使用的是qq邮箱，所以是smtp.qq.com，如果你使用的是126邮箱，那么就是smtp.126.com
                client.Host = "smtp.qq.com";
                //使用安全加密连接
                client.EnableSsl = true;
                //不和请求一块发送
                client.UseDefaultCredentials = false;
                //验证发件人身份(发件人的邮箱，邮箱里的生成授权码（授权码通过开启IMAP/SMTP服务后自动生成）)
                client.Credentials = new NetworkCredential("2715602713@qq.com", "ucwlobepcpuyddaa");
                //发送
                client.Send(mailMessage);//在QQ邮箱内开启IMAP/SMTP服务
                MessageBox.Show("成功发送！", "温馨提示");
                //button3.Text = "再次发送验证码";
            }
            else 
            {
                MessageBox.Show("您的邮箱和用户名不匹配，请重新输入！", "失败提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // 获取用户ID
            string userId = textBox1.Text;

            if (!string.IsNullOrEmpty(userId))
            {
                // 用 GetUserNameById 方法来查找用户姓名
                string userName = GetUserNameById(userId);
                textBox2.Text = userName; // 更新 textBox2 显示用户姓名
            }
            else
            {
                textBox2.Text = string.Empty; // 如果没有输入，清空 textBox2
            }
        }
        private string GetUserNameById(string userId)
        {
            string userName = string.Empty;

            Dao dao = new Dao();

            using (SqlConnection connection = dao.connect())
            {
                // 使用参数化查询
                string query = "SELECT Uname FROM Table_User WHERE Uxh = @UserId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // 添加参数
                    command.Parameters.AddWithValue("@UserId", userId);

                    // 执行查询
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // 确保列名匹配
                            userName = reader["Uname"].ToString(); // 使用正确的列名
                        }
                    }
                }
            }
            return userName;
            Dispose();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 阻止回车键的默认行为
            }
        }

        private void 忘记密码_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox2.BackColor = Color.White;
        }
    }
}